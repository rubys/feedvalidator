"""$Id: pievalidtest.py,v 1.2 2003/07/09 16:24:30 f8dy Exp $"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2003/07/09 16:24:30 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

import rssvalid
import unittest, new, os, sys, glob, re
from rssvalidtest import *

if __name__ == "__main__":
  curdir = os.path.abspath(os.path.dirname(sys.argv[0]))
  basedir = os.path.split(curdir)[0]
  for xmlfile in glob.glob(os.path.join(basedir, 'testcases', 'pie', '**', '*.xml')):
    method, description, params, exc = getDescription(xmlfile)
    testName = 'test_' + os.path.basename(xmlfile)
    testFunc = buildTestCase(xmlfile, description, method, exc, params)
    instanceMethod = new.instancemethod(testFunc, None, TestCase)
    setattr(TestCase, testName, instanceMethod)
  unittest.main()

__history__ = """
$Log: pievalidtest.py,v $
Revision 1.2  2003/07/09 16:24:30  f8dy
added global feed type support

Revision 1.1  2003/07/06 21:46:38  rubys
Add pievalidtest.py

"""
