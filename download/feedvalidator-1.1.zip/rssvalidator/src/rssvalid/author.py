"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2003/07/09 16:24:30 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *

#
# author element.
#
class author(validatorBase):
  def validate(self):
    if not "name" in self.children:
      self.log(MissingElement({"parent":self.name, "element":"name"}))

  def do_name(self):
    return nonhtml(), nonblank(), noduplicates()

  def do_weblog(self):
    return rfc2396(), noduplicates()

  def do_homepage(self):
    return rfc2396(), noduplicates()

__history__ = """
$Log: author.py,v $
Revision 1.2  2003/07/09 16:24:30  f8dy
added global feed type support

Revision 1.1  2003/07/07 00:54:00  rubys
Rough in some pie/echo support

"""
