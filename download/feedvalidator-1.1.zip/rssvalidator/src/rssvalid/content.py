"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2003/07/07 10:35:50 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# item element.
#
class content(validatorBase):
  mime_re = re.compile('[^\s()<>,;:\\"/[\]?=]+/[^\s()<>,;:\\"/[\]?=]+$')

  def prevalidate(self):
    if not self.attrs.has_key((None,'mode')):
      pass
    elif not self.attrs.getValue((None,'mode')) in ['xml','escaped','base64']:
      self.log(InvalidContentMode({'mode':self.attrs.getValue((None,'mode'))}))

    if not self.attrs.has_key((None,'type')):
      self.log(NoMIMEType({}))
    elif not self.mime_re.match(self.attrs.getValue((None,'type'))):
      self.log(InvalidMIMEType({'type':self.attrs.getValue((None,'type'))}))
    
  def validate(self):
    pass

__history__ = """
$Log: content.py,v $
Revision 1.2  2003/07/07 10:35:50  rubys
Complete first pass of echo/pie tests

Revision 1.1  2003/07/07 02:44:13  rubys
Further progress towards pie

"""
