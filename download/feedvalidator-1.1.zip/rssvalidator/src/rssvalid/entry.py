"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2003/07/07 10:35:50 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# pie/echo entry element.
#
class entry(validatorBase):

  def validate(self):
    if not 'author' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"author"}))
    if not 'id' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"id"}))
    if not 'link' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"link"}))

  def do_id(self):
    return nonblank(), rfc2396(), noduplicates()

  def do_link(self):
    return nonblank(), rfc2396(), noduplicates()

  def do_title(self):
    return nonhtml(), noduplicates()

  def do_subtitle(self):
    return nonhtml(), noduplicates()

  def do_summary(self):
    return nonhtml(), noduplicates()

  def do_author(self):
    from author import author
    return author(), noduplicates()

  def do_contributor(self):
    from author import author
    return author()

  def do_content(self):
    from content import content
    return content()

  def do_created(self):
    return iso8601_z(), noduplicates()
  
  def do_issued(self):
    return iso8601_l(), noduplicates()
  
  def do_modified(self):
    return iso8601_z(), noduplicates()
  
__history__ = """
$Log: entry.py,v $
Revision 1.3  2003/07/07 10:35:50  rubys
Complete first pass of echo/pie tests

Revision 1.2  2003/07/07 02:44:13  rubys
Further progress towards pie

Revision 1.1  2003/07/07 00:54:00  rubys
Rough in some pie/echo support

"""
