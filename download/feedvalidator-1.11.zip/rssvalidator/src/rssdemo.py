"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.13 $"
__date__ = "$Date: 2003/07/16 19:47:15 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

import rssvalid
import sys

if __name__ == '__main__':
  # arg 1 is URL to validate
  link = sys.argv[1:] and sys.argv[1] or 'http://www.intertwingly.net/blog/index.rss2'
  print 'Validating %s' % link
  
  events = rssvalid.validateURL(link, firstOccurrenceOnly=1)['loggedEvents']

  # (optional) arg 2 is compatibility level
  # "A" is most basic level
  # "AA" mimics online validator
  # "AAA" is experimental; these rules WILL change or disappear in future versions
  from rssvalid import compatibility
  filter = sys.argv[2:] and sys.argv[2] or "AA"
  filterFunc = getattr(compatibility, filter)
  events = filterFunc(events)

  from rssvalid.formatter.text_plain import Formatter
  output = Formatter(events)
  if output:
      print "\n".join(output)
  else:
      print "No errors or warnings"

__history__ = """
$Log: rssdemo.py,v $
Revision 1.13  2003/07/16 19:47:15  rubys
Remove debug statement

Revision 1.12  2003/07/10 21:16:33  rubys
Get rssdemo back on its feet...

Revision 1.11  2002/10/20 04:47:21  f8dy
*** empty log message ***

Revision 1.10  2002/10/20 04:41:21  f8dy
*** empty log message ***

Revision 1.9  2002/10/20 04:36:09  f8dy
cleaned up for public distribution

Revision 1.8  2002/10/18 13:06:57  f8dy
added licensing information

"""
