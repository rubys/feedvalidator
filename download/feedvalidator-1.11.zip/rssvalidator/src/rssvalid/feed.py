"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2003/07/09 16:24:30 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# Pie/Echo root element
#
class feed(validatorBase):
  def do_entry(self):
    from entry import entry
    return entry()

  def do_title(self):
    return nonblank(), nonhtml(), noduplicates()

  def do_subtitle(self):
    return nonblank(), nonhtml(), noduplicates()

  def do_link(self):
    return nonblank(), rfc2396(), noduplicates()
  
  def do_modified(self):
    return iso8601_z(), noduplicates()

  def prevalidate(self):
    self.setFeedType(TYPE_PIE)
    
  def validate(self):
    if (None,'version') not in self.attrs.getNames():
      self.log(MissingAttribute({"element":self.name, "attr":"version"}))
    elif not self.attrs.getValue((None,'version')):
      self.log(MissingAttribute({"element":self.name, "attr":"version"}))
    if not 'link' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"link"}))
    if not 'title' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"title"}))
    if not 'subtitle' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"subtitle"}))

__history__ = """
$Log: feed.py,v $
Revision 1.3  2003/07/09 16:24:30  f8dy
added global feed type support

Revision 1.2  2003/07/07 10:35:50  rubys
Complete first pass of echo/pie tests

Revision 1.1  2003/07/07 00:54:00  rubys
Rough in some pie/echo support

"""
