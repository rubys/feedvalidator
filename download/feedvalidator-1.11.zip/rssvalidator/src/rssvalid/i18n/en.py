"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.35 $"
__date__ = "$Date: 2003/07/19 21:15:08 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

import rssvalid
from rssvalid.logging import *

line = "line %(line)s"
column = "column %(column)s"
occurances = " (%(msgcount)s occurrences)"

messages = {
  SAXError:                "XML Parsing error: %(exception)s",
  UnicodeError:            "%(exception)s (maybe a high-bit character?)",
  UndefinedElement:        "Undefined %(parent)s element: %(element)s",
  MissingNamespace:        "Missing namespace for %(element)s",
  MissingElement:          "Missing %(parent)s element: %(element)s",
  MissingOptionalElement:  "%(parent)s should contain a %(element)s element",
  MissingRecommendedElement: "%(parent)s should contain a %(element)s element",
  MissingAttribute:        "Missing %(element)s attribute: %(attr)s",
  NoBlink:                 "There is no blink element in RSS; use blogChannel:blink instead",
  InvalidValue:            "Invalid value for %(element)s: \"%(value)s\"",
  InvalidWidth:            "%(element)s must be between 1 and 144",
  InvalidHeight:           "%(element)s must be between 1 and 400",
  InvalidHour:             "%(element)s must be between 1 and 24",
  InvalidDay:              "%(element)s must be Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, or Sunday",
  InvalidInteger:          "%(element)s must be a positive integer",
  InvalidHttpGUID:         "guid must be a full URL, unless isPermaLink attribute is false",
  InvalidUpdatePeriod:     "%(element)s must be hourly, daily, weekly, monthly, or yearly",
  RecommendedWidth:        "%(element)s should be between 1 and 88",
  RecommendedHeight:       "%(element)s should be between 1 and 31",
  NotBlank:                "%(element)s can not be blank",
  DuplicateElement:        "%(parent)s contains more than one %(element)s",
  DuplicateSemantics:      "A channel must not include both %(old)s and %(new)s",
  DuplicateItemSemantics:  "An item must not include both %(old)s and %(new)s",
  DuplicateValue:          "%(element)s values must not be duplicated within a feed",
  NonstdPrefix:            '"%(preferred)s" is the preferred prefix for the namespace "%(ns)s"',
  ReservedPrefix:          'The prefix "%(prefix)s" generally uses the namespace "%(ns)s"',
  UseModularEquivalent:    "%(new)s should be used instead of %(old)s",
  InvalidContact:          "%(element)s must include an email address",
  InvalidLink:             "%(element)s must be a full URL",
  InvalidW3DTFDate:        "%(element)s must be an ISO-8601 date",
  InvalidRFC2822Date:      "%(element)s must be an RFC-822 date",
  InvalidLanguage:         "%(element)s must be an ISO-639 language code",
  InvalidURLAttribute:     "%(attr)s attribute of %(element)s must be a full URL",
  InvalidIntegerAttribute: "%(attr)s attribute of %(element)s must be a positive integer",
  InvalidBooleanAttribute: "%(attr)s attribute of %(element)s must be 'true' or 'false'",
  InvalidMIMEAttribute:    "%(attr)s attribute of %(element)s must be a valid MIME type",
  ItemMustContainTitleOrDescription: "item must contain either title or description",
  ContainsHTML:            "%(element)s should not contain HTML",
  NotEnoughHoursInTheDay:  "skipHours can not contain more than 24 hour elements",
  EightDaysAWeek:          "skipDAys can not contain more than 7 day elements",
  SecurityRisk:            "%(element)s should not contain %(tag)s tag",
  ContainsRelRef:          "%(element)s should not contain relative URL references",
  ContainsSystemEntity:    "Feeds must not contain SYSTEM entities",
  InvalidURI:              "%(element)s must be a full URI",
  InvalidContentMode:      "mode must be 'xml', 'escaped', or 'base64'",
  InvalidMIMEType:         "Not a valid MIME type",
  NoMIMEType:              "%(element)s does not specify a MIME type",
  W3DTFDateNoTimezone:     "Date should include a timezone",
  W3DTFDateNonUTC:         "Date should be a UTC date",
  W3DTFDateNonLocal:       "Date should not be a UTC date",
  NotEscaped:              "%(element)s claims to be escaped, but isn't",
  NotInline:               "%(element)s claims to be inline, but isn't",
  NotBase64:               "%(element)s claims to be base64-encoded, but isn't"
}

__history__ = """
$Log: en.py,v $
Revision 1.35  2003/07/19 21:15:08  f8dy
added tests and logging classes for duplicate guid/id values within a feed (thanks AaronSw for this idea)

Revision 1.34  2003/07/09 19:28:39  f8dy
added test cases looking at actual content vs. mode (note: not passed)

Revision 1.33  2003/07/09 03:54:39  f8dy
yet more changes to the date messages

Revision 1.32  2003/07/09 03:48:04  f8dy
more changes to pie-specific messages

Revision 1.31  2003/07/09 03:31:36  f8dy
Updated pie-specific log messages

Revision 1.30  2003/06/26 18:03:04  f8dy
add workaround for case where SAX throws UnicodeError but locator.getLineNumber() is screwy

Revision 1.29  2002/10/31 00:52:21  rubys
Convert from regular expressions to EntityResolver for detecting
system entity references

Revision 1.28  2002/10/30 23:02:30  f8dy
*** empty log message ***

Revision 1.27  2002/10/30 15:44:48  rubys
Improve error messages for relative references: error message should
be gramatically correct.  Remove "hidden" fields prevented duplicate
errors from being flagged as such.

Revision 1.26  2002/10/27 18:54:30  rubys
Issue warnings for relative references in descriptions

Revision 1.25  2002/10/22 22:37:21  f8dy
tweaked ReservedPrefix message one last time

Revision 1.24  2002/10/22 19:32:19  f8dy
made friendlier messages for NonStdPrefix and ReservedPrefix

Revision 1.23  2002/10/22 16:24:04  f8dy
added UnicodeError support for feeds that declare utf-8 but use 8-bit characters anyway

Revision 1.22  2002/10/19 21:08:02  f8dy
added "special case" functionality for the web front end

Revision 1.21  2002/10/18 19:28:43  f8dy
added testcases for mod_syndication and passed them

Revision 1.20  2002/10/18 14:17:30  f8dy
added tests for language/dc:language (must be valid ISO-639 language code
plus optional country code) and passed them

Revision 1.19  2002/10/18 13:06:57  f8dy
added licensing information

"""
