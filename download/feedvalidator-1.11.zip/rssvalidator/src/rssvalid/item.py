"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.22 $"
__date__ = "$Date: 2003/07/20 17:44:27 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# item element.
#
class item(validatorBase):

  def validate(self):
    if not "link" in self.children:
      self.log(MissingItemLink({"parent":self.name, "element":"link"}))
    if not "title" in self.children:
      self.log(MissingItemTitle({"parent":self.name, "element":"title"}))
    if (not "title" in self.children) and (not "description" in self.children):
      self.log(ItemMustContainTitleOrDescription({}))

  def do_link(self):
    return rfc2396(), noduplicates()
  
  def do_comments(self):
    return rfc2396(), noduplicates()

  def do_annotate_reference(self):
    return annotate_reference(), noduplicates()
  
  def do_title(self):
    return nonhtml(), noduplicates()

  def do_description(self):
    return nonhtml(), noduplicates()

  def do_enclosure(self):
    return enclosure()
  
  def do_pubDate(self):
    if "dc_date" in self.children:
      self.log(DuplicateItemSemantics({"old":"pubDate", "new":"dc:date"}))
    self.log(UseDCDate({"old":"pubDate", "new":"dc:date"}))
    return rfc822(), noduplicates()

  def do_author(self):
    if "dc_creator" in self.children:
      self.log(DuplicateItemSemantics({"old":"author", "new":"dc:creator"}))
    self.log(UseDCCreator({"old":"author", "new":"dc:creator"}))
    return email(), noduplicates()

  def do_category(self):
    if "dc_subject" in self.children:
      self.log(DuplicateItemSemantics({"old":"category", "new":"dc:subject"}))
    self.log(UseDCSubject({"old":"category", "new":"dc:subject"}))
    return text()

  def do_dc_subject(self):
    if "category" in self.children:
      self.log(DuplicateItemSemantics({"old":"category", "new":"dc:subject"}))
    return text()

  def do_dc_creator(self):
    if "author" in self.children:
      self.log(DuplicateItemSemantics({"old":"author", "new":"dc:creator"}))
    return text()

  def do_dc_date(self):
    if "pubDate" in self.children:
      self.log(DuplicateItemSemantics({"old":"pubDate", "new":"dc:date"}))
    return iso8601(), noduplicates()

  def do_source(self):
    if "dc_source" in self.children:
      self.log(DuplicateItemSemantics({"old":"source", "new":"dc:source"}))
    self.log(UseDCSource({"old":"source", "new":"dc:source"}))
    return source(), noduplicates()

  def do_dc_source(self):
    if "source" in self.children:
      self.log(DuplicateItemSemantics({"old":"source", "new":"dc:source"}))
    return text(), noduplicates()

  def do_guid(self):
    return guid(), noduplicates(), unique('guid',self.parent)

  def do_content_encoded(self):
    return text(), noduplicates()

  def do_cc_license(self):
    if "creativeCommons_license" in self.children:
      self.log(DuplicateSemantics({"old":"creativeCommons:license", "new":"cc:license"}))
    return eater()

  def do_creativeCommons_license(self):
    if "cc_license" in self.children:
      self.log(DuplicateSemantics({"old":"creativeCommons:license", "new":"cc:license"}))
    return rfc2396()


class source(text, httpURLMixin):
  def prevalidate(self):
    try:
      self.validateHttpURL(None, 'url')
    except KeyError:
      self.log(MissingAttribute({"element":self.name, "attr":'url'}))
    return text.prevalidate(self)

class enclosure(validatorBase, httpURLMixin):
  mime_re = re.compile('[^\s()<>,;:\\"/[\]?=]+/[^\s()<>,;:\\"/[\]?=]+$')
  def prevalidate(self):
    try:
      if int(self.attrs.getValue((None, 'length'))) <= 0:
        self.log(InvalidIntegerAttribute({"element":self.name, "attr":'length'}))
    except KeyError:
      self.log(MissingAttribute({"element":self.name, "attr":'length'}))
    except ValueError:
      self.log(InvalidIntegerAttribute({"element":self.name, "attr":'length'}))

    try:
      if not self.mime_re.match(self.attrs.getValue((None, 'type'))):
        self.log(InvalidMIMEAttribute({"element":self.name, "attr":'type'}))
    except KeyError:
      self.log(MissingAttribute({"element":self.name, "attr":'type'}))

    try:
      self.validateHttpURL(None, 'url')
    except KeyError:
      self.log(MissingAttribute({"element":self.name, "attr":'url'}))

    return validatorBase.prevalidate(self)

class guid(rfc2396, noduplicates):
  def validate(self):
    isPermalink = 1
    try:
      isPermalinkStr = self.attrs.getValue((None, 'isPermaLink'))
      if isPermalinkStr not in ('true', 'false'):
        self.log(InvalidBooleanAttribute({"element":self.name, "attr":"isPermaLink"}))
      isPermalink = (isPermalinkStr == 'true')
    except KeyError:
      pass
    if isPermalink:
      return rfc2396.validate(self, InvalidHttpGUID)
    else:
      return noduplicates.validate(self)

class annotate_reference(rdfResourceURI): pass

__history__ = """
$Log: item.py,v $
Revision 1.22  2003/07/20 17:44:27  rubys
Detect duplicate ids and guids

Revision 1.21  2003/01/11 03:59:26  rubys
dashes are legal in MIME types

Revision 1.20  2002/12/20 13:26:00  rubys
CreativeCommons support

Revision 1.19  2002/10/24 14:47:33  f8dy
decoupled "no duplicates" check from individual validator classes,
allow handlers to return multiple validator classes

Revision 1.18  2002/10/22 17:29:52  f8dy
loosened restrictions on link/docs/url protocols; RSS now allows any
IANA protocol, not just http:// and ftp://

Revision 1.17  2002/10/18 15:46:35  f8dy
added (and passed) rule for no multiple content:encoded

Revision 1.16  2002/10/18 14:17:30  f8dy
added tests for language/dc:language (must be valid ISO-639 language code
plus optional country code) and passed them

Revision 1.15  2002/10/18 13:06:57  f8dy
added licensing information

"""
