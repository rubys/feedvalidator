"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2002/11/11 19:12:17 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from logging import *

#
# skipHours element
#
class skipHours(validatorBase):
  def prevalidate(self):
    self.log(UseSyndicationModule({"old":self.name, "new":"syndication module"}))
    
  def validate(self):
    if "hour" not in self.children:
      self.log(MissingElement({"parent":self.name, "element":"hour"}))
    if len(self.children) > 24:
      self.log(NotEnoughHoursInTheDay({}))

  def do_hour(self):
    return hour()

class hour(validatorBase):
  def validate(self):
    try:
      h = int(self.value)
      if (h < 0) or (h > 24):
        self.log(InvalidHour({"element":self.name, "value":self.value}))
    except ValueError:
      self.log(InvalidHour({"element":self.name, "value":self.value}))

__history__ = """
$Log: skipHours.py,v $
Revision 1.3  2002/11/11 19:12:17  rubys
Allow zero for hours

Revision 1.2  2002/10/18 13:06:57  f8dy
added licensing information

"""
