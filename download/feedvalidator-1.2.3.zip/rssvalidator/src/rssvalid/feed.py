"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.7 $"
__date__ = "$Date: 2003/08/05 15:03:19 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# Pie/Echo root element
#
class feed(validatorBase):
  def do_entry(self):
    from entry import entry
    return entry()

  def do_title(self):
    return nonblank(), nonhtml(), noduplicates()

  def do_tagline(self):
    return nonblank(), nonhtml(), noduplicates()

  def do_id(self):
    return nonblank(), rfc2396(), noduplicates()

  def do_link(self):
    return nonblank(), rfc2396(), noduplicates()
  
  def do_modified(self):
    return iso8601_z(), noduplicates()

  def do_author(self):
    from author import author
    return author(), noduplicates()

  def do_contributor(self):
    from author import author
    return author(), noduplicates()

  def do_copyright(self):
    return text(), nonblank(), noduplicates()

  def do_generator(self):
    from generator import generator
    return generator(), nonblank(), rfc2396(), noduplicates()

  def prevalidate(self):
    self.setFeedType(TYPE_PIE)
    
  def validate(self):
    try:
      version = self.attrs.getValue((None,'version'))
      if not version:
        self.log(MissingAttribute({"element":self.name, "attr":"version"}))
      elif version in ['0.1']:
        self.log(ObsoleteVersion({"element":self.name, "version":version}))
    except:
      self.log(MissingAttribute({"element":self.name, "attr":"version"}))
    if not 'link' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"link"}))
    if not 'title' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"title"}))

__history__ = """
$Log: feed.py,v $
Revision 1.7  2003/08/05 15:03:19  rubys
Handle complex (nested) content.  Remove copy/paste error in handing
of copyright.

Revision 1.6  2003/08/05 14:03:23  rubys
Tagline is optional

Revision 1.5  2003/08/05 07:59:04  rubys
Add feed(id,tagline,contributor)
Drop feed(subtitle), entry(subtitle)
Check for obsolete version, namespace
Check for incorrect namespace on feed element

Revision 1.4  2003/08/03 18:46:04  rubys
support author(url,email) and feed(author,copyright,generator)

Revision 1.3  2003/07/09 16:24:30  f8dy
added global feed type support

Revision 1.2  2003/07/07 10:35:50  rubys
Complete first pass of echo/pie tests

Revision 1.1  2003/07/07 00:54:00  rubys
Rough in some pie/echo support

"""
