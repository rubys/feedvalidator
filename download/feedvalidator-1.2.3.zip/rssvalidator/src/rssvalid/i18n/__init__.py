"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2002/10/18 13:06:57 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

__history__ = """
$Log: __init__.py,v $
Revision 1.2  2002/10/18 13:06:57  f8dy
added licensing information

"""
