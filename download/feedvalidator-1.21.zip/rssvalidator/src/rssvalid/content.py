"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.7 $"
__date__ = "$Date: 2003/08/05 15:03:19 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# item element.
#
class content(validatorBase):
  mime_re = re.compile('[^\s()<>,;:\\"/[\]?=]+/[^\s()<>,;:\\"/[\]?=]+$')

  def prevalidate(self):
    self.mode='xml'
    self.mixed=0
    if self.attrs.has_key((None,"mode")):
      self.mode=self.attrs.getValue((None,"mode"))

    if not self.mode in ['xml','escaped','base64']:
      self.log(InvalidContentMode({"parent":self.parent.name, "element":self.name, "mode":self.mode}))
    else:
      self.log(ValidContentMode({"parent":self.parent.name, "element":self.name, "mode":self.mode}))

    if not self.attrs.has_key((None,'type')):
      self.log(NoMIMEType({"parent":self.parent.name, "element":self.name}))
    elif not self.mime_re.match(self.attrs.getValue((None,'type'))):
      self.log(InvalidMIMEType({"parent":self.parent.name, "element":self.name, "attr":"type", "value":self.attrs.getValue((None,'type'))}))
    else:
      self.log(ValidMIMEAttribute({"parent":self.parent.name, "element":self.name, "attr":"type", "value":self.attrs.getValue((None,'type'))}))
    
  def validate(self):
    if self.mode == 'base64':
      import base64
      try:
        base64.decodestring(self.value)
      except:
        self.log(NotBase64({"parent":self.parent.name, "element":self.name,"value":self.value}))
    elif self.mode == 'xml':
      import re
      if re.search('</\w+>',self.value) and not self.mixed:
        self.log(NotInline({"parent":self.parent.name, "element":self.name,"value":self.value}))

  def startElementNS(self, name, qname, attrs):
    self.mixed=1
    if self.attrs.has_key((None,"mode")):
      if self.attrs.getValue((None,"mode")) == 'escaped':
        self.log(NotEscaped({"parent":self.parent.name, "element":self.name}))
    handler=eater()
    handler.parent=self
    handler.dispatcher=self
    self.push(handler)

__history__ = """
$Log: content.py,v $
Revision 1.7  2003/08/05 15:03:19  rubys
Handle complex (nested) content.  Remove copy/paste error in handing
of copyright.

Revision 1.6  2003/07/29 21:48:10  f8dy
tightened up test cases, added parent element check, changed negative test cases to positive

Revision 1.5  2003/07/11 16:36:08  rubys
Attempt to detect improper use of inline xml

Revision 1.4  2003/07/10 21:16:33  rubys
Get rssdemo back on its feet...

Revision 1.3  2003/07/10 21:02:16  rubys
Verify base64 and escaped

Revision 1.2  2003/07/07 10:35:50  rubys
Complete first pass of echo/pie tests

Revision 1.1  2003/07/07 02:44:13  rubys
Further progress towards pie

"""
