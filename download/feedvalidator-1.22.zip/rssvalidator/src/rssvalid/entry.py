"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.8 $"
__date__ = "$Date: 2003/08/05 14:28:26 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from validators import *
from logging import *

#
# pie/echo entry element.
#
class entry(validatorBase):

  def validate(self):
    if not 'title' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"title"}))
    if not 'author' in self.children and not 'author' in self.parent.children:
      self.log(MissingElement({"parent":self.name, "element":"author"}))
    if not 'modified' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"modified"}))
    if not 'issued' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"issued"}))
    if not 'id' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"id"}))
    if not 'link' in self.children:
      self.log(MissingElement({"parent":self.name, "element":"link"}))

  def do_id(self):
    return rfc2396(), noduplicates(), unique('id',self.parent)

  def do_link(self):
    return nonblank(), rfc2396(), noduplicates()

  def do_title(self):
    return nonhtml(), noduplicates()

  def do_summary(self):
    return nonhtml(), noduplicates()

  def do_author(self):
    from author import author
    return author(), noduplicates()

  def do_contributor(self):
    from author import author
    return author()

  def do_content(self):
    from content import content
    return content()

  def do_created(self):
    return iso8601_z(), noduplicates()
  
  def do_issued(self):
    return iso8601_l(), noduplicates()
  
  def do_modified(self):
    return iso8601_z(), noduplicates()
  
__history__ = """
$Log: entry.py,v $
Revision 1.8  2003/08/05 14:28:26  rubys
Allow author to be omitted from entries when present on the feed

Revision 1.7  2003/08/05 07:59:04  rubys
Add feed(id,tagline,contributor)
Drop feed(subtitle), entry(subtitle)
Check for obsolete version, namespace
Check for incorrect namespace on feed element

Revision 1.6  2003/07/20 17:48:50  rubys
Validate that titles are present

Revision 1.5  2003/07/20 17:44:27  rubys
Detect duplicate ids and guids

Revision 1.4  2003/07/20 16:35:57  rubys
Ensure that issued and modified are present exactly once

Revision 1.3  2003/07/07 10:35:50  rubys
Complete first pass of echo/pie tests

Revision 1.2  2003/07/07 02:44:13  rubys
Further progress towards pie

Revision 1.1  2003/07/07 00:54:00  rubys
Rough in some pie/echo support

"""
