"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.5 $"
__date__ = "$Date: 2003/07/29 19:38:07 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from logging import *

#
# Rss element.  The only valid child element is "channel"
#
class rss(validatorBase):
  def do_channel(self):
    from channel import channel
    return channel()

  def prevalidate(self):
    self.setFeedType(TYPE_RSS2) # could be anything in the 0.9x family, don't really care
    
  def validate(self):
    if not "channel" in self.children:
      self.log(MissingChannel({"parent":self.parent.name, "element":self.name, "attr":"channel"}))
    if (None,'version') not in self.attrs.getNames():
      self.log(MissingAttribute({"parent":self.parent.name, "element":self.name, "attr":"version"}))

__history__ = """
$Log: rss.py,v $
Revision 1.5  2003/07/29 19:38:07  f8dy
changed test cases to explicitly test for success (rather than the absence of failure)

Revision 1.4  2003/07/09 16:24:30  f8dy
added global feed type support

Revision 1.3  2002/10/18 13:06:57  f8dy
added licensing information

"""
