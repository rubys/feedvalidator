"""$Id: __init__.py,v 1.4 2003/12/11 16:32:08 f8dy Exp $"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.4 $"
__date__ = "$Date: 2003/12/11 16:32:08 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

__all__ = ['base', 'text_plain', 'text_html']

__history__ = """
$Log: __init__.py,v $
Revision 1.4  2003/12/11 16:32:08  f8dy
fixed id tags in header

Revision 1.3  2002/10/18 13:06:57  f8dy
added licensing information

"""
