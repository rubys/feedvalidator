"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.11 $"
__date__ = "$Date: 2002/10/18 13:06:57 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

import timeoutsocket
timeoutsocket.setDefaultSocketTimeout(10)
import urllib
from logging import *
from xml.sax import SAXParseException
from xml.sax.xmlreader import InputSource

MAXDATALENGTH = 200000

def validateStream(stream, firstOccurrenceOnly=0):
  """validate RSS from stream, returns events list"""
  from xml.sax import make_parser, handler
  from base import SAXDispatcher
  
  source = InputSource()
  source.setByteStream(stream)
  if hasattr(stream,'url'): source.setSystemId(stream.url)

  validator = SAXDispatcher()
  validator.setFirstOccurrenceOnly(firstOccurrenceOnly)

  parser = make_parser()
  parser.setFeature(handler.feature_namespaces, 1)
  parser.setContentHandler(validator)
  parser.setErrorHandler(validator)

  try:
    parser.parse(source)
  except SAXParseException:
    pass
  return validator

def validateString(aString, firstOccurrenceOnly=0):
  """validate RSS from string, returns events list"""
  from cStringIO import StringIO
  validator = validateStream(StringIO(aString), firstOccurrenceOnly)
  return validator.loggedEvents

def validateURL(url, firstOccurrenceOnly=1, wantRawData=0):
  """validate RSS from URL, returns events list, or (events, rawdata) tuple"""
  stream = urllib.urlopen(url)
  if wantRawData:
    from cStringIO import StringIO
    rawdata = stream.read(MAXDATALENGTH)
    stream.close()
    stream = StringIO(rawdata)
  validator = validateStream(stream, firstOccurrenceOnly)
  stream.close()
  if wantRawData:
    return validator.loggedEvents, rawdata
  else:
    return validator.loggedEvents

__all__ = ['base',
           'channel',
           'compatibility',
           'image',
           'item',
           'logging',
           'rdf',
           'root',
           'rss',
           'skipHours',
           'textInput',
           'util',
           'validators',
           'validateURL',
           'validateString',
           'validateStream']

__history__ = """
$Log: __init__.py,v $
Revision 1.11  2002/10/18 13:06:57  f8dy
added licensing information

"""
