"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.19 $"
__date__ = "$Date: 2002/10/22 13:16:03 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from logging import *
from validators import *

#
# channel element.
#
class channel(validatorBase):
  def validate(self):
    if not "description" in self.children:
      self.log(MissingDescription({"parent":self.name,"element":"description"}))
    if not "link" in self.children:
      self.log(MissingLink({"parent":self.name, "element":"link"}))
    if not "title" in self.children:
      self.log(MissingTitle({"parent":self.name, "element":"title"}))
    if not "dc_date" in self.children:
      self.log(MissingDCDate({"parent":self.name, "element":"dc:date"}))
    if not "dc_rights" in self.children:
      self.log(MissingDCRights({"parent":self.name, "element":"dc:rights"}))
    if not "dc_language" in self.children:
      self.log(MissingDCLanguage({"parent":self.name, "element":"dc:language"}))
    if self.children.count("image") > 1:
      self.log(DuplicateElement({"parent":self.name, "element":"image"}))
    if self.children.count("textInput") > 1:
      self.log(DuplicateElement({"parent":self.name, "element":"textInput"}))
    if self.children.count("skipHours") > 1:
      self.log(DuplicateElement({"parent":self.name, "element":"skipHours"}))
    if self.children.count("skipDays") > 1:
      self.log(DuplicateElement({"parent":self.name, "element":"skipDays"}))

  def do_image(self):
    from image import image
    return image()

  def do_item(self):
    from item import item
    return item()

  def do_items(self): # this actually should be from the rss1.0 ns
    return eater()

  def do_textInput(self):
    from textInput import textInput
    return textInput()
  do_textinput = do_textInput # technically only true for RSS 1.0, can we distinguish?

  def do_category(self):
    return text()

  def do_cloud(self):
    return cloud()
  
  do_rating = validatorBase.leaf

  def do_ttl(self):
    return ttl()
  
  def do_docs(self):
    return httpLink()
    
  def do_link(self):
    return httpOrFtpLink()

  def do_title(self):
    return nonhtml()

  def do_description(self):
    return nonhtml()

  def do_generator(self):
    if "admin_generatorAgent" in self.children:
      self.log(DuplicateSemantics({"old":"generator", "new":"admin:generatorAgent"}))
    self.log(UseAdminGeneratorAgent({"old":"generator", "new":"admin:generatorAgent"}))
    return simpleText()

  def do_pubDate(self):
    if "dc_date" in self.children:
      self.log(DuplicateSemantics({"old":"pubDate", "new":"dc:date"}))
    self.log(UseDCDate({"old":"pubDate", "new":"dc:date"}))
    return rfc822()

  def do_managingEditor(self):
    if "dc_creator" in self.children:
      self.log(DuplicateSemantics({"old":"managingEditor", "new":"dc:creator"}))
    self.log(UseDCCreator({"old":"managingEditor", "new":"dc:creator"}))
    return email()

  def do_webMaster(self):
    if "dc_publisher" in self.children:
      self.log(DuplicateSemantics({"old":"webMaster", "new":"dc:publisher"}))
    self.log(UseDCPublisher({"old":"webMaster", "new":"dc:publisher"}))
    return email()

  def do_dc_creator(self):
    if "managingEditor" in self.children:
      self.log(DuplicateSemantics({"old":"managingEditor", "new":"dc:creator"}))
    return simpleText()

  def do_dc_language(self):
    if "language" in self.children:
      self.log(DuplicateSemantics({"old":"language", "new":"dc:language"}))
    return iso639()

  def do_language(self):
    if "dc_language" in self.children:
      self.log(DuplicateSemantics({"old":"language", "new":"dc:language"}))
    self.log(UseDCLanguage({"old":"language", "new":"dc:language"}))
    return iso639()

  def do_dcterms_modified(self):
    if "lastBuildDate" in self.children:
      self.log(DuplicateSemantics({"old":"lastBuildDate", "new":"dcterms:modified"}))
    return iso8601()

  def do_dc_publisher(self):
    if "webMaster" in self.children:
      self.log(DuplicateSemantics({"old":"webMaster", "new":"dc:publisher"}))
    return simpleText()

  def do_copyright(self):
    if "dc_rights" in self.children:
      self.log(DuplicateSemantics({"old":"copyright", "new":"dc:copyright"}))
    self.log(UseDCRights({"old":"copyright", "new":"dc:copyright"}))
    return simpleText()

  def do_dc_rights(self):
    if "copyright" in self.children:
      self.log(DuplicateSemantics({"old":"copyright", "new":"dc:copyright"}))
    return simpleText()

  def do_dc_date(self):
    if "pubDate" in self.children:
      self.log(DuplicateSemantics({"old":"pubDate", "new":"dc:date"}))
    return iso8601()

  def do_admin_generatorAgent(self):
    if "generator" in self.children:
      self.log(DuplicateSemantics({"old":"generator", "new":"admin:generatorAgent"}))
    return admin_generatorAgent()

  def do_admin_errorReportsTo(self):
    return admin_errorReportsTo()

  def do_lastBuildDate(self):
    if "dcterms_modified" in self.children:
      self.log(DuplicateSemantics({"old":"lastBuildDate", "new":"dcterms:modified"}))
    self.log(UseDCTermsModified({"old":"lastBuildDate", "new":"dcterms:modified"}))
    return rfc822()

  def do_skipHours(self):
    from skipHours import skipHours
    return skipHours()

  def do_skipDays(self):
    from skipDays import skipDays
    return skipDays()

  def do_blogChannel_blogRoll(self):
    return httpLink()

  def do_blogChannel_mySubscriptions(self):
    return httpLink()

  def do_blogChannel_blink(self):
    return httpLink()

  def do_blink(self):
    return blink()

  def do_sy_updatePeriod(self):
    return sy_updatePeriod()

  def do_sy_updateFrequency(self):
    return sy_updateFrequency()

  def do_sy_updateBase(self):
    return iso8601()

class blink(validatorBase):
  def validate(self):
    self.log(NoBlink({}))
    
class cloud(validatorBase):
  def prevalidate(self):
    if (None, 'domain') not in self.attrs.getNames():
      self.log(MissingAttribute(({"element":self.name, "attr":"domain"})))

    try:
      if int(self.attrs.getValue((None, 'port'))) <= 0:
        self.log(InvalidIntegerAttribute({"element":self.name, "attr":'port'}))
    except KeyError:
      self.log(MissingAttribute({"element":self.name, "attr":'port'}))
    except ValueError:
      self.log(InvalidIntegerAttribute({"element":self.name, "attr":'port'}))

    if (None, 'path') not in self.attrs.getNames():
      self.log(MissingAttribute(({"element":self.name, "attr":"path"})))

    if (None, 'registerProcedure') not in self.attrs.getNames():
      self.log(MissingAttribute(({"element":self.name, "attr":"registerProcedure"})))

    if (None, 'protocol') not in self.attrs.getNames():
      self.log(MissingAttribute(({"element":self.name, "attr":"protocol"})))
    ## TODO - is there a list of accepted protocols for this thing?

    return validatorBase.prevalidate(self)

class ttl(positiveInteger): pass

class admin_generatorAgent(rdfResourceURI): pass
class admin_errorReportsTo(rdfResourceURI): pass

class sy_updateFrequency(positiveInteger): pass

class sy_updatePeriod(simpleText):
  def validate(self):
    if self.value not in ('hourly', 'daily', 'weekly', 'monthly', 'yearly'):
      self.log(InvalidUpdatePeriod({"element":self.name, "value":self.value}))

__history__ = """
$Log: channel.py,v $
Revision 1.19  2002/10/22 13:16:03  f8dy
passed lowercase textinput test

Revision 1.18  2002/10/18 19:28:43  f8dy
added testcases for mod_syndication and passed them

Revision 1.17  2002/10/18 15:41:33  f8dy
added (and passed) testcases for unallowed duplicates of the same element

Revision 1.16  2002/10/18 14:17:30  f8dy
added tests for language/dc:language (must be valid ISO-639 language code
plus optional country code) and passed them

Revision 1.15  2002/10/18 13:06:57  f8dy
added licensing information

"""
