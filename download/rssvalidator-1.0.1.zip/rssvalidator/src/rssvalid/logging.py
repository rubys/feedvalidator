"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.26 $"
__date__ = "$Date: 2002/10/18 19:28:43 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

#
# logging support
#

class LoggedEvent:
  def __init__(self, params):
    self.params = params
class Info(LoggedEvent): pass
class Warning(LoggedEvent): pass
class Error(LoggedEvent): pass

###################### error ######################

class SAXError(Error): pass

class UndefinedElement(Error): pass
class MissingNamespace(UndefinedElement): pass
class NoBlink(UndefinedElement): pass
class MissingAttribute(Error): pass
class DuplicateElement(Error): pass
class NotEnoughHoursInTheDay(Error): pass
class EightDaysAWeek(Error): pass

class InvalidValue(Error): pass
class InvalidContact(InvalidValue): pass
class InvalidLink(InvalidValue): pass
class InvalidW3DTFDate(InvalidValue): pass
class InvalidRFC2822Date(InvalidValue): pass
class InvalidURLAttribute(InvalidValue): pass
class InvalidIntegerAttribute(InvalidValue): pass
class InvalidBooleanAttribute(InvalidValue): pass
class InvalidMIMEAttribute(InvalidValue): pass
class NotBlank(InvalidValue): pass
class InvalidInteger(InvalidValue): pass
class InvalidWidth(InvalidValue): pass
class InvalidHeight(InvalidValue): pass
class InvalidHour(InvalidValue): pass
class InvalidDay(InvalidValue): pass
class InvalidHttpGUID(InvalidValue): pass
class InvalidLanguage(InvalidValue): pass
class InvalidUpdatePeriod(InvalidValue): pass

class MissingElement(Error): pass
class MissingChannel(MissingElement): pass
class MissingDescription(MissingElement): pass
class MissingLink(MissingElement): pass
class MissingTitle(MissingElement): pass
class ItemMustContainTitleOrDescription(MissingElement): pass

###################### warning ######################

class DuplicateSemantics(Warning): pass
class DuplicateItemSemantics(DuplicateSemantics): pass

class ReservedPrefix(Warning): pass

class SecurityRisk(Warning): pass
class ContainsScript(SecurityRisk): pass
class ContainsMeta(SecurityRisk): pass
class ContainsEmbed(SecurityRisk): pass
class ContainsObject(SecurityRisk): pass

###################### info ######################

class ContainsHTML(Info): pass

class MissingOptionalElement(Info): pass
class MissingItemLink(MissingOptionalElement): pass
class MissingItemTitle(MissingOptionalElement): pass

class BestPractices(Info): pass

class MissingRecommendedElement(BestPractices): pass
class MissingDCLanguage(MissingRecommendedElement): pass
class MissingDCRights(MissingRecommendedElement): pass
class MissingDCDate(MissingRecommendedElement): pass

class UseModularEquivalent(BestPractices): pass
class UseDCRights(UseModularEquivalent): pass
class UseAdminGeneratorAgent(UseModularEquivalent): pass
class UseDCCreator(UseModularEquivalent): pass
class UseDCSubject(UseModularEquivalent): pass
class UseDCDate(UseModularEquivalent): pass
class UseDCSource(UseModularEquivalent): pass
class UseDCLanguage(UseModularEquivalent): pass
class UseDCTermsModified(UseModularEquivalent): pass
class UseDCPublisher(UseModularEquivalent): pass
class UseSyndicationModule(UseModularEquivalent): pass
class UseAnnotateReference(UseModularEquivalent): pass

class RecommendedWidth(BestPractices): pass
class RecommendedHeight(BestPractices): pass

class NonstdPrefix(BestPractices): pass

__history__ = """
$Log: logging.py,v $
Revision 1.26  2002/10/18 19:28:43  f8dy
added testcases for mod_syndication and passed them

Revision 1.25  2002/10/18 14:17:30  f8dy
added tests for language/dc:language (must be valid ISO-639 language code
plus optional country code) and passed them

Revision 1.24  2002/10/18 13:06:57  f8dy
added licensing information

"""
