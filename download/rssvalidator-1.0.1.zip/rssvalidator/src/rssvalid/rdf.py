"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2002/10/22 13:16:03 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from logging import *

#
# rdf:RDF element.  The valid children include "channel" and "item"
#
class rdf(validatorBase):
  def do_channel(self):
    from channel import channel
    return channel()

  def do_item(self):
    from item import item
    return item()

  def do_textinput(self):
    from textInput import textInput
    return textInput()
  
  def validate(self):
    if not "channel" in self.children:
      self.log(MissingChannel({"element":self.name, "attr":"channel"}))

__history__ = """
$Log: rdf.py,v $
Revision 1.3  2002/10/22 13:16:03  f8dy
passed lowercase textinput test

Revision 1.2  2002/10/18 13:06:57  f8dy
added licensing information

"""
