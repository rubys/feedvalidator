"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2002/10/18 13:06:57 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from logging import *

#
# skipDays element
#
class skipDays(validatorBase):
  def prevalidate(self):
    self.log(UseSyndicationModule({"old":self.name, "new":"syndication module"}))
    
  def validate(self):
    if "day" not in self.children:
      self.log(MissingElement({"parent":self.name, "element":"day"}))
    if len(self.children) > 7:
      self.log(EightDaysAWeek({}))

  def do_day(self):
    return day()

class day(validatorBase):
  def validate(self):
    if self.value not in ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'):
      self.log(InvalidDay({"element":self.name, "value":self.value}))

__history__ = """
$Log: skipDays.py,v $
Revision 1.2  2002/10/18 13:06:57  f8dy
added licensing information

"""
