"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.14 $"
__date__ = "$Date: 2002/10/22 19:41:07 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

import timeoutsocket
timeoutsocket.setDefaultSocketTimeout(10)
import urllib
from logging import *
from xml.sax import SAXParseException
from xml.sax.xmlreader import InputSource

MAXDATALENGTH = 200000

def validateStream(stream, firstOccurrenceOnly=0):
  """validate RSS from stream, returns events list"""
  from xml.sax import make_parser, handler
  from base import SAXDispatcher
  from exceptions import UnicodeError
  
  source = InputSource()
  source.setByteStream(stream)
  if hasattr(stream,'url'): source.setSystemId(stream.url)

  validator = SAXDispatcher()
  validator.setFirstOccurrenceOnly(firstOccurrenceOnly)

  parser = make_parser()
  parser.setFeature(handler.feature_namespaces, 1)
  parser.setContentHandler(validator)
  parser.setErrorHandler(validator)

  try:
    parser.parse(source)
  except SAXParseException:
    pass
  except UnicodeError:
    import sys
    exctype, value = sys.exc_info()[:2]
    import logging
    validator.log(logging.UnicodeError({"exception":value}))
#  except:
#    import sys
#    exctype, value = sys.exc_info()[:2]
#    print exctype, value
  return validator

def validateString(aString, firstOccurrenceOnly=0):
  """validate RSS from string, returns events list"""
  from cStringIO import StringIO
  validator = validateStream(StringIO(aString), firstOccurrenceOnly)
  return validator.loggedEvents

def validateURL(url, firstOccurrenceOnly=1, wantRawData=0):
  """validate RSS from URL, returns events list, or (events, rawdata) tuple"""
  stream = urllib.urlopen(url)
  if wantRawData:
    from cStringIO import StringIO
    rawdata = stream.read(MAXDATALENGTH)
    rawdata = rawdata.replace('\r\n', '\n').replace('\r', '\n') # normalize EOL
    stream.close()
    stream = StringIO(rawdata)
  validator = validateStream(stream, firstOccurrenceOnly)
  stream.close()
  if wantRawData:
    return validator.loggedEvents, rawdata
  else:
    return validator.loggedEvents

__all__ = ['base',
           'channel',
           'compatibility',
           'image',
           'item',
           'logging',
           'rdf',
           'root',
           'rss',
           'skipHours',
           'textInput',
           'util',
           'validators',
           'validateURL',
           'validateString',
           'validateStream']

__history__ = """
$Log: __init__.py,v $
Revision 1.14  2002/10/22 19:41:07  f8dy
normalize line endings before parsing (SAX parser is not Mac-CR-friendly)

Revision 1.13  2002/10/22 16:35:11  f8dy
commented out fallback except (caller handles it gracefully anyway)

Revision 1.12  2002/10/22 16:24:04  f8dy
added UnicodeError support for feeds that declare utf-8 but use 8-bit characters anyway

Revision 1.11  2002/10/18 13:06:57  f8dy
added licensing information

"""
