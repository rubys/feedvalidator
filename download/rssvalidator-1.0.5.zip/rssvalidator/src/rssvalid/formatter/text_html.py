"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.7 $"
__date__ = "$Date: 2002/10/18 13:06:57 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

"""Output class for plain text output"""

from base import BaseFormatter
import rssvalid
import cgi

class Formatter(BaseFormatter):
  FRAGMENTLEN = 80
  DOCSURL = 'http://feeds.archive.org/validator/docs/'
  
  def __init__(self, events, rawdata):
    BaseFormatter.__init__(self, events)
    self.rawdata = rawdata
    
  def getRootClass(self, aClass):
    base = aClass.__bases__[0]
    if base.__name__.split('.')[-1] == 'LoggedEvent':
      return aClass
    else:
      return self.getRootClass(base)

  def getHelpURL(self, event):
    rootClass = self.getRootClass(event.__class__).__name__
    rootClass = rootClass.split('.')[-1]
    rootClass = rootClass.lower()
    return self.DOCSURL + rootClass + '/' + event.__class__.__name__.split('.')[-1]
    
  def format(self, event):
    if event.params.has_key('line'):
      line = event.params['line']
      column = event.params['column']
      codeFragment = self.rawdata.split('\n')[line-1]
      markerColumn = column
      if column > self.FRAGMENTLEN:
        codeFragment = '... ' + codeFragment[column-(self.FRAGMENTLEN/2):]
        markerColumn = 5 + (self.FRAGMENTLEN/2)
      if len(codeFragment) > self.FRAGMENTLEN:
        codeFragment = codeFragment[:(self.FRAGMENTLEN-4)] + ' ...'
    else:
      codeFragment = ''
    return """<li>
  <p><a href="#l%s">%s</a>, %s: <span class="message">%s</span>%s [<a title="more information about this error" href="%s">help</a>]</p>
  <blockquote><p><code>%s<br />%s<span class="marker">%s</span></code></p></blockquote>
</li>
""" % (line, self.getLine(event),
       self.getColumn(event),
       self.getMessage(event),
       self.getCount(event),
       self.getHelpURL(event),
       cgi.escape(codeFragment),
       '&nbsp;' * (markerColumn - 1),
       '^')

__history__ = """
$Log: text_html.py,v $
Revision 1.7  2002/10/18 13:06:57  f8dy
added licensing information

"""
