"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.22 $"
__date__ = "$Date: 2002/10/19 21:08:02 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

import rssvalid
from rssvalid.logging import *

line = "line %(line)s"
column = "column %(column)s"
occurances = " (%(msgcount)s occurrences)"

messages = {
  SAXError:                "XML Parsing error: %(exception)s",
  UndefinedElement:        "Undefined %(parent)s element: %(element)s",
  MissingNamespace:        "Missing namespace for %(element)s",
  MissingElement:          "Missing %(parent)s element: %(element)s",
  MissingOptionalElement:  "%(parent)s should contain a %(element)s element",
  MissingRecommendedElement: "%(parent)s should contain a %(element)s element",
  MissingAttribute:        "Missing %(element)s attribute: %(attr)s",
  NoBlink:                 "There is no blink element in RSS; use blogChannel:blink instead",
  InvalidValue:            "Invalid value for %(element)s: \"%(value)s\"",
  InvalidWidth:            "%(element)s must be between 1 and 144",
  InvalidHeight:           "%(element)s must be between 1 and 400",
  InvalidHour:             "%(element)s must be between 1 and 24",
  InvalidDay:              "%(element)s must be Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, or Sunday",
  InvalidInteger:          "%(element)s must be a positive integer",
  InvalidHttpGUID:         "guid must be a full URL, unless isPermaLink attribute is false",
  InvalidUpdatePeriod:     "%(element)s must be hourly, daily, weekly, monthly, or yearly",
  RecommendedWidth:        "%(element)s should be between 1 and 88",
  RecommendedHeight:       "%(element)s should be between 1 and 31",
  NotBlank:                "%(element)s can not be blank",
  DuplicateElement:        "%(parent)s contains more than one %(element)s",
  DuplicateSemantics:      "A channel must not include both %(old)s and %(new)s",
  DuplicateItemSemantics:  "An item must not include both %(old)s and %(new)s",
  NonstdPrefix:            "%(preferred)s is the preferred prefix for %(ns)s",
  ReservedPrefix:          "%(prefix)s is generally used for %(ns)s instead",
  UseModularEquivalent:    "%(new)s should be used instead of %(old)s",
  InvalidContact:          "%(element)s must include an email address",
  InvalidLink:             "%(element)s must be a full URL",
  InvalidW3DTFDate:        "%(element)s must be an ISO-8601 date",
  InvalidRFC2822Date:      "%(element)s must be an RFC-822 date",
  InvalidLanguage:         "%(element)s must be an ISO-639 language code",
  InvalidURLAttribute:     "%(attr)s attribute of %(element)s must be a full URL",
  InvalidIntegerAttribute: "%(attr)s attribute of %(element)s must be a positive integer",
  InvalidBooleanAttribute: "%(attr)s attribute of %(element)s must be 'true' or 'false'",
  InvalidMIMEAttribute:    "%(attr)s attribute of %(element)s must be a valid MIME type",
  ItemMustContainTitleOrDescription: "item must contain either title or description",
  ContainsHTML:            "%(element)s should not contain HTML",
  NotEnoughHoursInTheDay:  "skipHours can not contain more than 24 hour elements",
  EightDaysAWeek:          "skipDAys can not contain more than 7 day elements",
  SecurityRisk:            "%(element)s should not contain %(tag)s tag"
}

__history__ = """
$Log: en.py,v $
Revision 1.22  2002/10/19 21:08:02  f8dy
added "special case" functionality for the web front end

Revision 1.21  2002/10/18 19:28:43  f8dy
added testcases for mod_syndication and passed them

Revision 1.20  2002/10/18 14:17:30  f8dy
added tests for language/dc:language (must be valid ISO-639 language code
plus optional country code) and passed them

Revision 1.19  2002/10/18 13:06:57  f8dy
added licensing information

"""
