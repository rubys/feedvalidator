"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.3 $"
__date__ = "$Date: 2002/10/18 13:06:57 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from validators import *

#
# textInput element.
#
class textInput(validatorBase):
  def validate(self):
    if not "title" in self.children:
      self.log(MissingTitle({"parent":self.name, "element":"title"}))
    if not "link" in self.children:
      self.log(MissingLink({"parent":self.name, "element":"link"}))
    if not "description" in self.children:
      self.log(MissingDescription({"parent":self.name,"element":"description"}))
    if not "name" in self.children:
      self.log(MissingElement({"parent":self.name, "element":"name"}))

  def do_title(self):
    return nonhtml()

  def do_description(self):
    return nonhtml()

  def do_name(self):
    return nonhtml()

  def do_link(self):
    return httpLink()

__history__ = """
$Log: textInput.py,v $
Revision 1.3  2002/10/18 13:06:57  f8dy
added licensing information

"""
