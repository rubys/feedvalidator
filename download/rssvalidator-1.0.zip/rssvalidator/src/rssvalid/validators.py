"""$Id"""

__author__ = "Sam Ruby <http://intertwingly.net/> and Mark Pilgrim <http://diveintomark.org/>"
__version__ = "$Revision: 1.19 $"
__date__ = "$Date: 2002/10/20 13:36:59 $"
__copyright__ = "Copyright (c) 2002 Sam Ruby and Mark Pilgrim"
__license__ = "Python"

from base import validatorBase
from logging import *
import re

#
# This class simply eats events.  Useful to prevent cascading of errors
#
class eater(validatorBase):
  def startElementNS(self, name, qname, attrs):
    handler=eater()
    handler.parent=self
    self.push(handler)

#
# text: i.e., no child elements allowed (except rdf:Description).
#
class text(validatorBase):
  def startElementNS(self, name, qname, attrs):
    from base import namespaces
    if name<>'Description' or namespaces.get(qname,'')<>'rdf':
      self.log(UndefinedElement({"parent":self.name, "element":name}))
    handler=eater()
    handler.parent=self
    self.push(handler)

#
# simpleText: no child elements, no duplicate siblings
#
class simpleText(text):
  def prevalidate(self):
    if self.name in self.parent.children:
      self.log(DuplicateElement({"parent":self.parent.name, "element":self.name}))

#
# valid e-mail addresses
#
class email(simpleText):
  email_re = re.compile("[\w\-\.]+@[\w\-\.]+\s*(\(.*\))?$")
  def validate(self):
    if not self.email_re.match(self.value):
      self.log(InvalidContact({"element":self.name, "value":self.value}))

#
# iso639 language code
#
class iso639(simpleText):
  def validate(self):
    import iso639codes
    if '-' in self.value:
      lang, sublang = self.value.split('-', 1)
    else:
      lang = self.value
    if not iso639codes.isoLang.has_key(lang):
      self.log(InvalidLanguage({"element":self.name, "value":self.value}))

#
# iso8601 dateTime
#
class iso8601(simpleText):
  iso8601_re = re.compile("\d\d\d\d(-\d\d(-\d\d(T\d\d:\d\d(:\d\d(.\d*)?)?" +
                       "(Z|([+-]\d\d:\d\d))?)?)?)?$")
  def validate(self):
    if not self.iso8601_re.match(self.value):
      self.log(InvalidW3DTFDate({"element":self.name, "value":self.value}))

#
# rfc2396 uri
#
class rfc2396(simpleText):
  rfc2396_re = re.compile("(([a-zA-Z][0-9a-zA-Z+\\-\\.]*:)(//){0,2}" +
    "[0-9a-zA-Z;/?:@&=+$\\.\\-_!~*'()%]+)?" +
    "(#[0-9a-zA-Z;/?:@&=+$\\.\\-_!~*'()%]+)?$")
  def validate(self):
    if not self.rfc2396_re.match(self.value):
      self.log(InvalidLink({"element":self.name, "value":self.value}))

#
# rfc822 dateTime (+Y2K extension)
#
class rfc822(simpleText):
  rfc822_re = re.compile("(((Mon)|(Tue)|(Wed)|(Thu)|(Fri)|(Sat)|(Sun)), )?" +
    "\d\d? ((Jan)|(Feb)|(Mar)|(Apr)|(May)|(Jun)|(Jul)|(Aug)|(Sep)|(Oct)|" +
    "(Nov)|(Dec)) \d\d(\d\d)? \d\d:\d\d:\d\d (([+-]?\d\d\d\d)|" +
    "(UT)|(GMT)|(EST)|(EDT)|(CST)|(CDT)|(MST)|(MDT)|(PST)|(PDT)|\w)$")
  def validate(self):
    if not self.rfc822_re.match(self.value):
      self.log(InvalidRFC2822Date({"element":self.name, "value":self.value}))

#
# Elements for which html is discouraged
#
class nonhtml(simpleText):
  htmlEndTag_re = re.compile("</\w+>")
  scriptTag_re = re.compile("<script", re.IGNORECASE)
  metaTag_re = re.compile("<meta", re.IGNORECASE)
  embedTag_re = re.compile("<embed", re.IGNORECASE)
  objectTag_re = re.compile("<object", re.IGNORECASE)
  def validate(self):
    if self.htmlEndTag_re.search(self.value):
      self.log(ContainsHTML({"element":self.name}))
    if self.scriptTag_re.search(self.value):
      self.log(ContainsScript({"element":self.name, "tag":"script"}))
    if self.metaTag_re.search(self.value):
      self.log(ContainsMeta({"element":self.name, "tag":"meta"}))
    if self.embedTag_re.search(self.value):
      self.log(ContainsEmbed({"element":self.name, "tag":"embed"}))
    if self.objectTag_re.search(self.value):
      self.log(ContainsObject({"element":self.name, "tag":"object"}))

#
# 
class httpOrFtpLink(rfc2396):
  protocol_re = re.compile("((http)|(ftp))://", re.IGNORECASE)
  def validate(self, errorClass=InvalidLink):
    if not self.protocol_re.match(self.value):
      self.log(errorClass({"element":self.name, "value":self.value}))
    else:
      rfc2396.validate(self)

class httpLink(httpOrFtpLink):
  protocol_re = re.compile("http://", re.IGNORECASE)

class positiveInteger(simpleText):
  def validate(self):
    try:
      t = int(self.value)
      if t <= 0:
        self.log(InvalidInteger({"element":self.name, "value":self.value}))
    except ValueError:
      self.log(InvalidInteger({"element":self.name, "value":self.value}))
  
#
# mixin to validate URL in attribute
#
class httpURLMixin:
  http_re = re.compile("http://", re.IGNORECASE)
  def validateHttpURL(self, ns, attr):
    value = self.attrs[(ns, attr)]
    if not self.http_re.search(value):
      self.log(InvalidURLAttribute({"element":self.name, "attr":attr}))

class rdfResourceURI(rfc2396):
  rdfNS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
  def validate(self):
    if (self.rdfNS, 'resource') not in self.attrs.getNames():
      self.log(MissingAttribute({"element":self.name, "attr":"rdf:resource"}))
    else:
      self.value=self.attrs.getValue((self.rdfNS, 'resource'))
      rfc2396.validate(self)

__history__ = """
$Log: validators.py,v $
Revision 1.19  2002/10/20 13:36:59  rubys
Permit rdf:Description anywhere text is allowed

Revision 1.18  2002/10/18 19:28:43  f8dy
added testcases for mod_syndication and passed them

Revision 1.17  2002/10/18 15:41:33  f8dy
added (and passed) testcases for unallowed duplicates of the same element

Revision 1.16  2002/10/18 14:17:30  f8dy
added tests for language/dc:language (must be valid ISO-639 language code
plus optional country code) and passed them

Revision 1.15  2002/10/18 13:06:57  f8dy
added licensing information

"""
